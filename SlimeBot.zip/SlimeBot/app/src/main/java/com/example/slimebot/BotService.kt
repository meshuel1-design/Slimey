package com.example.slimebot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Path
import android.graphics.PixelFormat
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Gravity
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button

class BotService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private lateinit var cfg: Settings
    private lateinit var button: Button
    private var running = false
    private var healing = false
    private var healthPct = 100
    private var lastShot = 0L

    override fun onServiceConnected() {
        cfg = Settings(this)
        addOverlay()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() { stop() }
    override fun onDestroy() { stop(); runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(button) }; super.onDestroy() }

    // ---- floating start/stop button (accessibility overlay, no extra permission) ----
    private fun addOverlay() {
        button = Button(this).apply {
            text = "▶ Start"; textSize = 12f
            setOnClickListener { if (running) stop() else start() }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 8 }
        (getSystemService(WINDOW_SERVICE) as WindowManager).addView(button, lp)
    }

    private fun start() { cfg = Settings(this); running = true; healing = false; button.text = "⏸ Stop"; handler.post(tapLoop); handler.post(healthLoop) }
    private fun stop() { running = false; handler.removeCallbacksAndMessages(null); if (::button.isInitialized) button.text = "▶ Start" }

    // ---- swing loop ----
    private val tapLoop = object : Runnable {
        override fun run() {
            if (!running) return
            if (!healing) tap()
            handler.postDelayed(this, cfg.tapMs.toLong())
        }
    }

    private fun tap() {
        val dm = resources.displayMetrics
        val path = Path().apply { moveTo(dm.widthPixels * cfg.tapX, dm.heightPixels * cfg.tapY) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 40)).build()
        dispatchGesture(g, null, null)
    }

    // ---- health check loop (screenshots are rate limited to ~1/sec) ----
    private val healthLoop = object : Runnable {
        override fun run() {
            if (!running) return
            takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
                override fun onSuccess(r: ScreenshotResult) {
                    val hw = r.hardwareBuffer
                    val bmp = Bitmap.wrapHardwareBuffer(hw, r.colorSpace)?.copy(Bitmap.Config.ARGB_8888, false)
                    hw.close()
                    if (bmp != null) { healthPct = readHealth(bmp); bmp.recycle(); updateState() }
                }
                override fun onFailure(code: Int) {}
            })
            handler.postDelayed(this, 1100)
        }
    }

    /** % of the health bar strip that is "bright" (filled). Empty part of the bar is dark. */
    private fun readHealth(b: Bitmap): Int {
        val x0 = (b.width * cfg.barLeft).toInt(); val x1 = (b.width * cfg.barRight).toInt()
        val y = (b.height * cfg.barY).toInt()
        var filled = 0; var total = 0
        for (x in x0 until x1) {
            var bright = 0
            for (dy in -1..1) {
                val c = b.getPixel(x, (y + dy).coerceIn(0, b.height - 1))
                if (maxOf(Color.red(c), Color.green(c), Color.blue(c)) >= cfg.brightness) bright++
            }
            if (bright >= 2) filled++
            total++
        }
        return if (total == 0) 0 else filled * 100 / total
    }

    private fun updateState() {
        if (!healing && healthPct < cfg.lowPct) healing = true
        else if (healing && healthPct >= cfg.resumePct) healing = false
        button.text = (if (healing) "💚 Healing " else "⚔ Attacking ") + healthPct + "%"
    }
}
