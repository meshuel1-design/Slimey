package com.example.slimebot

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings as AndroidSettings
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val cfg = Settings(this)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(48, 64, 48, 48) }

        fun text(t: String) = TextView(this).apply { text = t; textSize = 15f; setPadding(0, 16, 0, 8) }
        fun slider(label: String, min: Int, max: Int, get: () -> Int, set: (Int) -> Unit) {
            val tv = text("$label: ${get()}")
            val sb = SeekBar(this).apply {
                this.max = max - min; progress = get() - min
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(b: SeekBar?, p: Int, u: Boolean) { set(p + min); tv.text = "$label: ${p + min}" }
                    override fun onStartTrackingTouch(b: SeekBar?) {}
                    override fun onStopTrackingTouch(b: SeekBar?) {}
                })
            }
            col.addView(tv); col.addView(sb)
        }

        col.addView(TextView(this).apply { text = "Slime Bot"; textSize = 26f })
        col.addView(text("1. Tap the button below and turn on 'Slime Bot' in Accessibility.\n" +
            "2. Open Roblox (landscape). A Start button floats at the top of the screen.\n" +
            "3. Face the slimes and press Start. It swings automatically and pauses when your health is low, resuming once you've healed."))
        col.addView(Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { startActivity(Intent(AndroidSettings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        slider("Pause to heal below (% health)", 5, 90, { cfg.lowPct }) { cfg.lowPct = it }
        slider("Resume attacking at (% health)", 20, 100, { cfg.resumePct }) { cfg.resumePct = it }
        slider("Swing every (ms)", 100, 1000, { cfg.tapMs }) { cfg.tapMs = it }
        slider("Health bar brightness cutoff", 80, 250, { cfg.brightness }) { cfg.brightness = it }
        col.addView(text("If the floating % looks wrong, adjust the brightness cutoff until it reads ~100% at full health."))
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
