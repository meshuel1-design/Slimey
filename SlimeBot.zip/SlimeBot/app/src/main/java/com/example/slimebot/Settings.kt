package com.example.slimebot

import android.content.Context

/** Simple persisted settings. Fractions are 0..1 of screen size (landscape). */
class Settings(ctx: Context) {
    private val p = ctx.getSharedPreferences("slimebot", Context.MODE_PRIVATE)

    var lowPct: Int            // pause attacking below this health %
        get() = p.getInt("low", 35); set(v) = p.edit().putInt("low", v).apply()
    var resumePct: Int         // resume attacking at/above this health %
        get() = p.getInt("resume", 90); set(v) = p.edit().putInt("resume", v).apply()
    var tapMs: Int             // time between swings
        get() = p.getInt("tapMs", 300); set(v) = p.edit().putInt("tapMs", v).apply()
    var brightness: Int        // pixel counts as "filled health" if its brightest channel >= this
        get() = p.getInt("bright", 170); set(v) = p.edit().putInt("bright", v).apply()

    // Where to tap to swing (Roblox swings the held tool on a tap in the world view)
    val tapX = 0.55f
    val tapY = 0.50f

    // Health bar strip, measured from your video (top-right of the screen)
    val barLeft = 0.805f
    val barRight = 0.935f
    val barY = 0.082f
}
