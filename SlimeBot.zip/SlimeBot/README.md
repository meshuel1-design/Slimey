# Slime Bot (Android)

Build: open this folder in Android Studio (Hedgehog or newer), let Gradle sync, then Run on your phone (Android 11+).
Enable: Slime Bot > Open Accessibility settings > Slime Bot > On.
Use: open Roblox in landscape, face slimes, tap the floating Start button.

Notes
- It taps at 55%/50% of the screen (swings the held sword) every N ms and reads the health bar at the top right.
- Below the "pause" % it stops swinging; it resumes at the "resume" %.
- It does NOT aim or walk. Stand where slimes come to you, or reposition when needed.
- Health bar location is in Settings.kt (barLeft/barRight/barY) if your device layout differs.
- Roblox prohibits automation; use at your own risk.

## Build with GitHub (no Android Studio)
1. Create a new GitHub repo and upload all files in this folder (keep the `.github` folder).
2. Open the repo's **Actions** tab. The "Build APK" workflow runs on every push (or press **Run workflow**).
3. When it finishes (about 3-5 min), open the run and download **SlimeBot-apk** under Artifacts.
4. Unzip it, send `app-debug.apk` to your phone, and install it (allow "install unknown apps" if asked).
